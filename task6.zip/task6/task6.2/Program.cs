﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace task6._2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Введите строку: "); //пример: аргентина манит негра
            var inp = Console.ReadLine();
            var wos = new String(inp.Where(c => c != ' ').Select(c => Char.ToLower(c)).ToArray());
            var rev = new String(wos.Reverse().ToArray());
            Console.WriteLine(wos == rev ? "строка -- палиндром" : "строка -- не палиндром");
            Console.ReadKey();
        }
    }
}
